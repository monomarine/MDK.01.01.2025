﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Popov_30
{
    public class Account : ISave
    {
        private int id;
        private double balance;
        private double annualInterestRate;
        private DateTime dateCreated;

        private bool isLocked = false;

        public Account()
        {
            id = 0;
            balance = 0;
            annualInterestRate = 0;
            dateCreated = DateTime.Now;
            isLocked = false;
        }

        public Account(int id, double balance)
        {
            this.id = id;
            this.balance = balance;
            annualInterestRate = 0;
            dateCreated = DateTime.Now;
            isLocked = false;
        }

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public double Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        public double AnnualInterestRate
        {
            get { return annualInterestRate; }
            set { annualInterestRate = value; }
        }

        public DateTime DateCreated
        {
            get { return dateCreated; }
        }

        public bool IsLocked
        {
            get { return isLocked; }
        }

        public int Summ
        {
            get { return (int)balance; } 
            set { balance = value; }
        }

        public void AddMoney(int amount)
        {
            if (IsLocked)
                throw new InvalidOperationException("Счет заблокирован. Невозможно пополнить.");

            if (amount <= 0)
                throw new ArgumentException("Сумма пополнения должна быть положительной");

            balance += amount;
        }

        public int DecMoney(int amount)
        {
            if (IsLocked)
                throw new InvalidOperationException("Счет заблокирован. Невозможно снять средства.");

            if (amount <= 0)
                throw new ArgumentException("Сумма снятия должна быть положительной");

            if (amount > balance)
                throw new InvalidOperationException("Недостаточно средств на счете");

            balance -= amount;
            return amount;
        }

        public void Lock()
        {
            isLocked = true;
        }

        public void Unlock()
        {
            isLocked = false;
        }

        public double GetMonthlyInterest()
        {
            if (IsLocked)
                throw new InvalidOperationException("Счет заблокирован. Невозможно рассчитать проценты.");

            double monthlyInterestRate = annualInterestRate / 100 / 12;
            return balance * monthlyInterestRate;
        }

        public void Withdraw(double amount)
        {
            if (IsLocked)
                throw new InvalidOperationException("Счет заблокирован. Невозможно снять средства.");

            if (amount <= 0)
                throw new ArgumentException("Сумма снятия должна быть положительной");

            if (amount > balance)
                throw new InvalidOperationException("Недостаточно средств на счете");

            balance -= amount;
        }

        public void Deposit(double amount)
        {
            if (IsLocked)
                throw new InvalidOperationException("Счет заблокирован. Невозможно пополнить счет.");

            if (amount <= 0)
                throw new ArgumentException("Сумма пополнения должна быть положительной");

            balance += amount;
        }

        public override string ToString()
        {
            string lockStatus = IsLocked ? "заблокирован" : "разблокирован";
            return $"Счет ID: {id}, Баланс: {balance:F2} руб., Статус: {lockStatus}, " +
                   $"Процентная ставка: {annualInterestRate}%, Дата создания: {dateCreated:dd.MM.yyyy}";
        }
    }
}
