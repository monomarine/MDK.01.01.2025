﻿namespace Popov_30
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Account account = new Account(1122, 20000);
                account.AnnualInterestRate = 4.5;

                Console.WriteLine("=== Создание счета ===");
                Console.WriteLine(account);
                Console.WriteLine();

                Console.WriteLine("=== Базовые операции ===");
                account.Withdraw(2500);
                Console.WriteLine($"Снятие: 2500 руб.");
                account.Deposit(3000);
                Console.WriteLine($"Пополнение: 3000 руб.");
                Console.WriteLine($"Текущий баланс: {account.Balance:F2} руб.");
                Console.WriteLine($"Ежемесячные проценты: {account.GetMonthlyInterest():F2} руб.");
                Console.WriteLine();

                Console.WriteLine("=== Тестирование ISave интерфейса ===");

                
                account.AddMoney(1000);
                Console.WriteLine($"Пополнение через AddMoney: 1000 руб.");
                Console.WriteLine($"Баланс: {account.Summ} руб.");

                int withdrawn = account.DecMoney(500);
                Console.WriteLine($"Снятие через DecMoney: {withdrawn} руб.");
                Console.WriteLine($"Баланс: {account.Summ} руб.");
                Console.WriteLine();

                Console.WriteLine("=== Тестирование блокировки ===");
                account.Lock();
                Console.WriteLine($"Счет заблокирован: {account.IsLocked}");

                try
                {
                    account.Withdraw(100);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при снятии: {ex.Message}");
                }

                account.Unlock();
                Console.WriteLine($"Счет разблокирован: {!account.IsLocked}");
                account.Deposit(500);
                Console.WriteLine($"Пополнение после разблокировки: 500 руб.");
                Console.WriteLine();

                Console.WriteLine("=== Итоговая информация ===");
                Console.WriteLine(account);
                Console.WriteLine($"Ежемесячные проценты: {account.GetMonthlyInterest():F2} руб.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}
